class S2NInputError(Exception):
    pass


class S2NLengthError(Exception):
    pass


class GradientError(Exception):
    pass


class InstError(Exception):
    pass
